﻿[void][reflection.assembly]::LoadWithPartialName("system.windows.forms")
$form=new-object system.windows.Forms.Form
$form.text="GUI-Form"
$button=new-object system.windows.Forms.Button
$button.text="Click Me!"
$button.dock="fill"
$button.add_click({$form.close()})
$form.controls.add($button)
$form.add_shown({$form.activate()})
$form.showdialog()